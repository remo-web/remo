# Aurora Standard Login Form web client module 
Displays standard login form with ability to pass login and password

# License
This module is licensed under AGPLv3 license if free version of the product is used or Afterlogic Software License if commercial version of the product was purchased.
