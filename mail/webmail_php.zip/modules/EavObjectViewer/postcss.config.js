module.exports = {
  plugins: {
    autoprefixer: {},
  },
};
