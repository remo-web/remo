# aurora-module-dropbox
Adds ability to work with Dropbox

# License
This module is licensed under AGPLv3 license if free version of the product is used or Afterlogic Software License if commercial version of the product was purchased.